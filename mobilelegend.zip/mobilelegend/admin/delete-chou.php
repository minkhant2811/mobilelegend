<?php
include("connection.php"); 
error_reporting(1);
$q = "delete from choulist where id='{$_GET['id']}'";
$con->query($q);
unlink("img/".$_GET['img']);
header('location:chou.php');
?>

