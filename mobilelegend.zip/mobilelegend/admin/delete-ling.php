<?php
include("connection.php"); 
error_reporting(1);
$q = "delete from linglist where id='{$_GET['id']}'";
$con->query($q);
unlink("img/".$_GET['img']);
header('location:ling.php');
?>

