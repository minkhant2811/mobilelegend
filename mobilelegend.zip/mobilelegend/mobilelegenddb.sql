-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 08, 2024 at 05:06 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mobilelegentdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `ID` int(40) NOT NULL,
  `Name` varchar(100) NOT NULL,
  `Email` varchar(300) NOT NULL,
  `Message` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`ID`, `Name`, `Email`, `Message`) VALUES
(1, 'ZinZin', 'zin9898@gmail.com', 'dsaijsi shdsdhsdsdsd dsdssdds'),
(2, 'MinMin', 'min9898@gmail.com', 'dsaijsi shdsdhsdsdsd dsdssdds'),
(3, 'Khant', 'khant9898@gmail.com', 'dsaijsi shdsdhsdsdsd dsdssdds'),
(4, 'AungAung', 'aung9898@gmail.com', 'very good service');

-- --------------------------------------------------------

--
-- Table structure for table `drinklist`
--

CREATE TABLE `hayabusalist` (
  `ID` int(100) NOT NULL,
  `NAME` varchar(300) NOT NULL,
  `price` int(100) NOT NULL,
  `Email` varchar(500) NOT NULL,
  `image` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `drinklist`
--

INSERT INTO `hayabusat` (`ID`, `NAME`, `price`, `Email`, `image`) VALUES
(1, 'hayabusaepic', 3009, 'min123@gmail.com', '12334.webp'),
(4, 'hayabusa1111', 1000, 'zinmin123@gmail.com', '12345.webp');

-- --------------------------------------------------------

--
-- Table structure for table `foodlist`
--

CREATE TABLE `gusinlist` (
  `ID` int(11) NOT NULL,
  `NAME` varchar(200) NOT NULL,
  `price` int(20) NOT NULL,
  `Email` varchar(500) NOT NULL,
  `image` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `foodlist`
--

INSERT INTO `gusinlist` (`ID`, `NAME`, `price`, `Email`, `image`) VALUES
(6, 'gusincollector', 3000, 'zaw1234@gmail.com', '1222.jpg'),
(8, 'gusinepic', 10000, 'kyaw123@gmail.com','gusin1.jpg');

-- --------------------------------------------------------

--
--
-- Table structure for table `foodlist`
--

CREATE TABLE `linglist` (
  `ID` int(11) NOT NULL,
  `NAME` varchar(200) NOT NULL,
  `price` int(20) NOT NULL,
  `Email` varchar(500) NOT NULL,
  `image` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `foodlist`
--

INSERT INTO `linglist` (`ID`, `NAME`, `price`, `Email`, `image`) VALUES
(6, 'lingincollector', 3000, 'zaw1234@gmail.com', 'dragon.jpg'),
(8, 'lingepic', 10000, 'kyaw123@gmail.com','gusin1.jpg');

-- --------------------------------------------------------

--
CREATE TABLE `fannylist` (
  `ID` int(11) NOT NULL,
  `NAME` varchar(200) NOT NULL,
  `price` int(20) NOT NULL,
  `Email` varchar(500) NOT NULL,
  `image` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `foodlist`
--

INSERT INTO `fannylist` (`ID`, `NAME`, `price`, `Email`, `image`) VALUES
(6, 'lingincollector', 3000, 'zaw1234@gmail.com', 'dragon.jpg'),
(8, 'lingepic', 10000, 'kyaw123@gmail.com','gusin1.jpg');

-- --------------------------------------------------------

--


--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `drinklist`
--
ALTER TABLE `hayabusalist`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `foodlist`
--
ALTER TABLE `gusinlist`
  ADD PRIMARY KEY (`ID`);

-- Indexes for table `foodlist`
--
ALTER TABLE `linglist`
  ADD PRIMARY KEY (`ID`);

-- Indexes for table `foodlist`
--
ALTER TABLE `fannylist`
  ADD PRIMARY KEY (`ID`);

-- Indexes for table `foodlist`
--
ALTER TABLE `saberlist`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `foodlist`
--
ALTER TABLE `choulist`
  ADD PRIMARY KEY (`ID`);

-- Indexes for table `order`
--
ALTER TABLE `order`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `contact`
--
ALTER TABLE `contact`
  MODIFY `ID` int(40) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `drinklist`
--
ALTER TABLE `hayabusalist`
  MODIFY `ID` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `foodlist`
--
ALTER TABLE `gusinlist`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `foodlist`
--
ALTER TABLE `lingist`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `foodlist`
--
ALTER TABLE `fannylist`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `foodlist`
--
ALTER TABLE `saberlist`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `foodlist`
--
ALTER TABLE `choulist`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `order`
--
ALTER TABLE `order`
  MODIFY `ID` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
