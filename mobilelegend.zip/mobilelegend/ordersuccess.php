<body style="background-color:#f2f2f2;">
<div>
    <br>
      <center>
      <img src="image/thankss.png" width="150"/><br>
      <img src="image/ordersuccesss.gif" width="600"/><br>
     <a href="index.html"> <img src="image/home.png" width="100"/></a>
      <br>
      </center>
       </div>
</body>
      
